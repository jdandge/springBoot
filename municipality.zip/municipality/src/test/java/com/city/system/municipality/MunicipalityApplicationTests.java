package com.city.system.municipality;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MunicipalityApplicationTests {

	@Test
	void contextLoads() {
	}

}
