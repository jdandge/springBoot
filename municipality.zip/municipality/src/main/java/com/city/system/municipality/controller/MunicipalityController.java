package com.city.system.municipality.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.city.system.municipality.exception.type.NoDataFoundException;
import com.city.system.municipality.services.MunicipalityRegisterService;

@RestController
public class MunicipalityController {
	
	MunicipalityRegisterService registerservice;
	
	
	@GetMapping("/start")
	public String example() {
		throw new NoDataFoundException("mtcn");
	}
	
 
    


}
