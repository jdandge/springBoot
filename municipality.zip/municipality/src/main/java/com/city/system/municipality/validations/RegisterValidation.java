package com.city.system.municipality.validations;

import org.springframework.stereotype.Component;

public class RegisterValidation {

}
