package com.city.system.municipality.exception.type;


public class NoDataFoundException extends RuntimeException {

    public NoDataFoundException(String notFoundData) {

        super(notFoundData +"  not found!!");
    }
}