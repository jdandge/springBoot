package com.city.system.municipality.services;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.city.system.municipality.exception.type.NoDataFoundException;

@Service
public class MunicipalityRegisterService {
	
	
	public String example() {
		
		
		throw new NoDataFoundException("mtcn");
	}
	

}
